package domain;

 interface Expirable {
    public boolean isExpired ();
}


