package Interface;

public interface DomainI
{
    public void load ();
    public void store ();
    public void addNonFoodItem (String name, double price, String[] materials);
}
